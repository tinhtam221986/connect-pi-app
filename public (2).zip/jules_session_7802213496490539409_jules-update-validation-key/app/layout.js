import './globals.css'
import Script from 'next/script'

export const metadata = {
  title: 'CONNECT',
  description: 'Pi Network Social App',
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <Script 
          src="https://sdk.minepi.com/pi-sdk.js" 
          strategy="beforeInteractive" 
        />
        {children}
      </body>
    </html>
  )
}
