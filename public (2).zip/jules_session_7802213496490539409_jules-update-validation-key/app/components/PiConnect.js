'use client'
import { useState, useEffect } from 'react'

export default function PiConnect() {
  const [status, setStatus] = useState("⏳ Đang tìm kiếm Pi Network...")

  useEffect(() => {
    const initPi = async () => {
      try {
        if (window.Pi) {
          // Initialize Pi SDK
          // version: "2.0" and sandbox: true are crucial for testnet
          await window.Pi.init({ version: "2.0", sandbox: true })
          setStatus("✅ Đã kết nối Pi Network Testnet")
        } else {
          // If Pi is not found immediately, it might still be loading if script strategy was different,
          // but with beforeInteractive it should be there. 
          // However, sometimes in Pi Browser it takes a moment.
          console.warn("window.Pi not found immediately")
        }
      } catch (error) {
        console.error("Pi Init Error:", error)
        setStatus(`❌ Lỗi kết nối: ${error.message}`)
      }
    }

    // Try initializing immediately if window.Pi exists
    if (window.Pi) {
      initPi()
    } else {
      // Otherwise wait for load event
      const onWindowLoad = () => {
         if (window.Pi) initPi();
      };
      window.addEventListener('load', onWindowLoad);
      
      // Safety check: Polling for a few seconds in case load event missed or script delayed
      const intervalId = setInterval(() => {
        if (window.Pi) {
            clearInterval(intervalId);
            initPi();
        }
      }, 500);

      // Stop polling after 5 seconds to avoid infinite loop
      setTimeout(() => clearInterval(intervalId), 5000);

      return () => {
        window.removeEventListener('load', onWindowLoad);
        clearInterval(intervalId);
      }
    }
  }, [])

  return (
    <div className="status-box">
      <p className={`status-text ${
        status.includes("✅") ? "status-success" : 
        status.includes("❌") ? "status-error" : 
        "status-loading"
      }`}>
        {status}
      </p>
    </div>
  )
}
