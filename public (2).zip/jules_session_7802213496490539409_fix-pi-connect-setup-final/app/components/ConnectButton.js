'use client'
import { useState, useEffect } from 'react'
import Script from 'next/script'

export default function ConnectButton() {
  const [status, setStatus] = useState("⏳ Đang tìm kiếm Pi Network...")
  const [isScriptLoaded, setIsScriptLoaded] = useState(false)

  // Function to handle the initialization once the script is ready
  const initializePi = async () => {
    try {
      if (window.Pi) {
        setStatus("⚙️ Đang khởi tạo SDK...")
        // Always use sandbox: true for development/testnet
        await window.Pi.init({ version: "2.0", sandbox: true })
        setStatus("✅ Đã kết nối Pi Network Testnet")
      } else {
        setStatus("❌ Không tìm thấy Pi SDK (window.Pi missing)")
      }
    } catch (err) {
      console.error(err)
      setStatus(`❌ Lỗi kết nối: ${err.message}`)
    }
  }

  return (
    <div className="status-box">
      {/* 
        We use strategy="afterInteractive" to ensure the script loads 
        after the page is interactive, avoiding blocking issues.
        onLoad guarantees we only try to init after the script is fully executed.
      */}
      <Script 
        src="https://sdk.minepi.com/pi-sdk.js" 
        strategy="afterInteractive" 
        onLoad={() => {
          setIsScriptLoaded(true)
          initializePi()
        }}
        onError={() => setStatus("❌ Không thể tải Pi SDK Script")}
      />
      
      <p className={`status-text ${
        status.includes("✅") ? "status-success" : 
        status.includes("❌") ? "status-error" : 
        "status-loading"
      }`}>
        {status}
      </p>

      {/* Optional: Retry button if connection fails or hangs */}
      {(!status.includes("✅") && isScriptLoaded) && (
        <button 
          onClick={initializePi}
          style={{
            marginTop: '10px',
            padding: '8px 16px',
            backgroundColor: '#F39C12',
            color: 'white',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer'
          }}
        >
          Thử lại
        </button>
      )}
    </div>
  )
}
