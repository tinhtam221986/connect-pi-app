import ConnectButton from './components/ConnectButton'

export default function Home() {
  return (
    <main className="main-container">
      <h1 className="title">CONNECT</h1>
      <ConnectButton />
    </main>
  )
}
